﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.Entities;
using HRDS.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HRDS.DAL
{
    public class EmployeeDAL
    {
        static SqlConnection cn = null;
        static SqlCommand cmd = null;
        SqlDataReader dr = null;

        public EmployeeDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public bool AddEmpDAl(Employee objemp)
        {
            bool empadded = false;
            try
            {
                cmd = new SqlCommand("[190305].[InsertEmployee]", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter empid = new SqlParameter("@id", objemp.EmployeeId);
                SqlParameter empname = new SqlParameter("@name", objemp.EmployeeName);
                SqlParameter designation = new SqlParameter("@designation", objemp.DesignationId);
                SqlParameter dept = new SqlParameter("@department", objemp.DepartmentId);
                cmd.Parameters.Add(empid);
                cmd.Parameters.Add(empname);
                cmd.Parameters.Add(designation);
                cmd.Parameters.Add(dept);
 
                cn.Open();
                cmd.ExecuteNonQuery();
                empadded = true;
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
            return empadded;
        }

        public bool UpdateEmpDAl(Employee objemp)
        {
            bool empupdated = false;
            try
            {
                cmd = new SqlCommand("[190305].[UpdateEmployee]", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter empid = new SqlParameter("@id", objemp.EmployeeId);
                SqlParameter empname = new SqlParameter("@name", objemp.EmployeeName);
                SqlParameter designation = new SqlParameter("@designation", objemp.DesignationId);
                SqlParameter dept = new SqlParameter("@department", objemp.DepartmentId);
                cmd.Parameters.Add(empid);
                cmd.Parameters.Add(empname);
                cmd.Parameters.Add(designation);
                cmd.Parameters.Add(dept);

                cn.Open();
                cmd.ExecuteNonQuery();
                empupdated = true;
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
            return empupdated;
        }

        public bool DeleteEmpDAl(int id)
        {
            bool empdeleted = false;
            try
            {
                cmd = new SqlCommand("[190305].[DeleteEmployee]", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter empid = new SqlParameter("@id", id);
                cmd.Parameters.Add(empid);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch(SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
            return empdeleted;
        }

        public Employee SearchEmpDAl(int id)
        {
            Employee obj = new Employee();
            try
            {
                cmd = new SqlCommand("[190305].[SearchEmployee]", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter empid = new SqlParameter("@id", SqlDbType.Int);
                SqlParameter empname = new SqlParameter("@name", SqlDbType.VarChar,15);
                SqlParameter designation = new SqlParameter("@designatio", SqlDbType.Int);
                SqlParameter dept = new SqlParameter("@department", SqlDbType.Int);

                empid.Direction = ParameterDirection.Input;
                empname.Direction = ParameterDirection.Output;
                designation.Direction = ParameterDirection.Output;
                dept.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(empid);
                cmd.Parameters.Add(empname);
                cmd.Parameters.Add(designation);
                cmd.Parameters.Add(dept);

                empid.Value = id;

                cn.Open();
                cmd.ExecuteNonQuery();
                obj.EmployeeId = id;
                obj.EmployeeName = empname.Value as string;
                obj.DesignationId = Convert.ToInt32(designation.Value);
                obj.DepartmentId = Convert.ToInt32(dept.Value); ;
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
            return obj;
        }

        public List <Employee> ListEmpDAl()
        {
            List<Employee> objlist = null;
            try
            {
                cmd = new SqlCommand("[190305].[ListEmployee]", cn);
                cmd.CommandType = CommandType.StoredProcedure;              
                cn.Open();
                while (dr.Read())
                {
                    Employee obj = new Employee();
                    obj.EmployeeId = Convert.ToInt32(dr[0]);
                    obj.EmployeeName = dr[1].ToString();
                    obj.DesignationId = Convert.ToInt32(dr[2]);
                    obj.DepartmentId = Convert.ToInt32(dr[3]);
                    objlist.Add(obj);
                }
                cmd.ExecuteNonQuery();                
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
            return objlist;
        }

    }
}
