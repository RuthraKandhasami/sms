﻿CREATE PROCEDURE [190305].[DeleteEmployee]
	@id int
AS
Begin
	delete [190305].EmpHRDS where EmployeeID = @id
END
RETURN 0