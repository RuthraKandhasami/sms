﻿CREATE PROCEDURE [190305].[InsertEmployee]
	@id int,
	@name varchar(15),
	@designation varchar(15),
	@department varchar(15)
AS
Begin
	insert into [190305].EmpHRDS values(@id,@name,@designation,@department)
End
RETURN 0