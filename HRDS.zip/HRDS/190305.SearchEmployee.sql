﻿CREATE PROCEDURE [190305].[SearchEmployee]
	@id int,
	@name varchar(15) output,
	@designation varchar(15) output,
	@department varchar(15) output
As
Begin
	select
	@name = EmployeeName,
	@designation = Designation,
	@department = Department
	from [190305].EmpHRDS
	where EmployeeID = @id
ENd
RETURN 0