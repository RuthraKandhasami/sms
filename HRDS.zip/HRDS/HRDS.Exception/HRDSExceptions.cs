﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.Entities;

namespace HRDS.Exceptions
{
    public class HRDSExceptions : ApplicationException
    {
        public HRDSExceptions(): base()
        {

        }
        public HRDSExceptions(string msg) : base(msg)
        {

        }
        public HRDSExceptions(string msg, Exception innerexception) : base(msg,innerexception)
        {

        }
    }
}
