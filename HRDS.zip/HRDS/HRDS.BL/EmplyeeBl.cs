﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.Entities;
using HRDS.Exceptions;
using HRDS.DAL;

namespace HRDS.BL
{
    public class EmplyeeBl
    {
        EmployeeDAL objdal = new EmployeeDAL();

        public bool AddBL(Employee objemp)
        {
            bool empAdded = false;
            try
            {
                   empAdded = objdal.AddEmpDAl(objemp);

            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empAdded;
        }

        public bool UpdateBL(Employee objemp)
        {
            bool empUpdated = false;
            try
            {
                empUpdated = objdal.UpdateEmpDAl(objemp);

            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        public bool DeleteBL(int id)
        {
            bool empdeleted = false;
            try
            {
                empdeleted = objdal.DeleteEmpDAl(id);

            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empdeleted;
        }

        public Employee SearchBL(int id)
        {
            Employee empfound = null;
            try
            {
                empfound = objdal.SearchEmpDAl(id);
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empfound;
        }

        public List<Employee> ListEmpBL()
        {
            List<Employee> list = null;
            try
            {
                list = objdal.ListEmpDAl();
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
    }
}
