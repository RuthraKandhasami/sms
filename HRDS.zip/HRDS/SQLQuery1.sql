﻿create table [190305].[Designation]
(
	DeignationID INT Primary key,
	DesginationName varchar(15)
)
insert into [190305].[Designation] values(100,'HR')
insert into [190305].[Designation] values(101,'HR')
insert into [190305].[Designation] values(102,'Admin')
insert into [190305].[Designation] values(103,'Admin')
insert into [190305].[Designation] values(104,'Support')

select * from [190305].[Designation]
drop table [190305].[Designation]

create table [190305].[Department]
(
	DepartmentID INT Primary key,
	DepartmentName varchar(15),
	Head varchar(10),
	Location varchar(12)
)
insert into [190305].[Department] values(200,'.Net','Ruthra','Chennai')
insert into [190305].[Department] values(201,'JAVA','Aishu','Mumbai')
insert into [190305].[Department] values(202,'.Net','Humera','Andhra')
insert into [190305].[Department] values(203,'.Net','Abc','Delhi')
insert into [190305].[Department] values(204,'JAVA','Xyz','Pune')

select * from [190305].[Department]
drop table [190305].[Department]

create table [190305].[EmpHRDS]
(
	EmployeeID INT Primary key,
	EmployeeName varchar(15),
	Designation varchar(15),
	Department varchar(15),
)













