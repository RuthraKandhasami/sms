﻿CREATE PROCEDURE [190305].[UpdateEmployee]
	@id int,
	@name varchar(15),
	@designation varchar(15),
	@department varchar(15)
As
Begin
	update [190305].EmpHRDS set
	EmployeeName = @name,
	Designation =@designation,
	Department = @department
	where EmployeeID = @id
End
RETURN 0