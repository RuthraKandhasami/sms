﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS_Exceptions;
using HRDS_Entities;
using HRDS_DataAccessLayer;
using System.Text.RegularExpressions;
using System.Data;
namespace HRDS_BusinessLayer
{
    public class EmployeeBL
    {    

        public static bool Validation(Employee employee)
        {
            bool isvalid = true;
            StringBuilder str = new StringBuilder();
            if(!Regex.Match(employee.Name,"^[A-Z][A-Za-z]*$").Success)
            {
                isvalid = false;
                str.Append("\nName should not contain NUmbers.");
            }
            if (!Regex.Match(employee.Id.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                str.Append("\nID should be in Numbers.");
            }
            if (!Regex.Match(employee.Designation.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                str.Append("\nDesignation number should be in Numbers.");
            }
            if (!Regex.Match(employee.Department.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                str.Append("\nDepartment number should be in Numbers.");
            }
            if(isvalid == false)
            {
                throw new HRDSExceptions(str.ToString());
            }
            return isvalid;
        }

        public static bool AddEmployeeBL(Employee employee)
        {
            bool employeeAdded = false;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                employeeAdded = objDAL.AddEmployeeDAL(employee);
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            return employeeAdded;
        }

        public static bool UpdateEmployeeBL(Employee employee)
        {
            bool employeeUpdated = false;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                employeeUpdated = objDAL.UpdateEmployeeDAL(employee);
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            return employeeUpdated;
        }

        public static bool DeleteEmployeeBL(int empid)
        {
            bool employeeDeleted = false;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                employeeDeleted = objDAL.DeleteEmployeeDAL(empid);
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            return employeeDeleted;
        }

        public static Employee SearchEmployeeBL(int empid)
        {
            Employee employeeSearch = null;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                employeeSearch = objDAL.SearchEmployeeDAL(empid);
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            return employeeSearch;
        }

        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> employeeGetAll = null;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                employeeGetAll = objDAL.GetAllEmployeeDAL();
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            return employeeGetAll;
        }

        public static DataTable getDesigBL()
        {
            DataTable desiglist;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                desiglist = objDAL.getDesigDAL();
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return desiglist;
        }

        public static DataTable getDeptBL()
        {
            DataTable deptlist;
            try
            {
                EmployeeDAL objDAL = new EmployeeDAL();
                deptlist = objDAL.getDeptDAL();
            }
            catch (HRDSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptlist;
        }

    }
}
