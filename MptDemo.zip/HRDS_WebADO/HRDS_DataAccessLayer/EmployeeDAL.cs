﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS_Entities;
using HRDS_Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HRDS_DataAccessLayer
{
    public class EmployeeDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;

        public bool AddEmployeeDAL(Employee employee)
        {
            bool employeeAdded = false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_InsertEmployee]",con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlParameter_id = new SqlParameter("@Empid",employee.Id);
                SqlParameter sqlParameter_Name = new SqlParameter("@EmpName",employee.Name);
                SqlParameter sqlParameter_desig = new SqlParameter("@EmpDesig",employee.Designation);
                SqlParameter sqlParameter_depart = new SqlParameter("@EmpDept",employee.Department);

                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_desig);
                cmd.Parameters.Add(sqlParameter_depart);

                con.Open();
                cmd.ExecuteNonQuery();
                employeeAdded = true;                
            }
            catch(SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return employeeAdded;
        }

        public bool UpdateEmployeeDAL(Employee employee) {
            bool employeeUpdated= false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_UpdateEmployee]",con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlParameter_id = new SqlParameter("@Empid", employee.Id);
                SqlParameter sqlParameter_Name = new SqlParameter("@EmpName", employee.Name);
                SqlParameter sqlParameter_desig = new SqlParameter("@EmpDesig", employee.Designation);
                SqlParameter sqlParameter_depart = new SqlParameter("@EmpDept", employee.Department);

                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_desig);
                cmd.Parameters.Add(sqlParameter_depart);

                con.Open();
                cmd.ExecuteNonQuery();
                employeeUpdated = true;
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return employeeUpdated;
        }

        public bool DeleteEmployeeDAL(int empId)
        {
            bool employeeDeleted = false;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_DeleteEmployee]",con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlParameter_id = new SqlParameter("@Empid", empId);
                
                cmd.Parameters.Add(sqlParameter_id);              

                con.Open();
                cmd.ExecuteNonQuery();
                employeeDeleted = true;
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return employeeDeleted;
        }

        public Employee SearchEmployeeDAL(int empid) {
            Employee employee = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_SearchEmployee]",con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlParameter_id = new SqlParameter("@Empid", SqlDbType.Int);
                SqlParameter sqlParameter_Name = new SqlParameter("@EmpName", SqlDbType.VarChar,50);
                SqlParameter sqlParameter_Desig = new SqlParameter("@EmpDept", SqlDbType.Int);
                SqlParameter sqlParameter_Dept = new SqlParameter("@EmpDesig", SqlDbType.Int);

                sqlParameter_id.Direction = ParameterDirection.Input;
                sqlParameter_Name.Direction = ParameterDirection.Output;
                sqlParameter_Desig.Direction = ParameterDirection.Output;
                sqlParameter_Dept.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(sqlParameter_id);
                cmd.Parameters.Add(sqlParameter_Name);
                cmd.Parameters.Add(sqlParameter_Desig);
                cmd.Parameters.Add(sqlParameter_Dept);

                sqlParameter_id.Value = empid;

                con.Open();
                cmd.ExecuteNonQuery();
                employee = new Employee();
                employee.Id = empid;
                employee.Name = sqlParameter_Name.Value.ToString();
                employee.Designation = Convert.ToInt32(sqlParameter_Desig.Value);
                employee.Department = Convert.ToInt32(sqlParameter_Dept.Value); ;
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return employee;
        }

        public List<Employee> GetAllEmployeeDAL()
        {
            List<Employee> employees = new List<Employee>();
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_SelectEmployee]",con);
                cmd.CommandType = CommandType.StoredProcedure;
                
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read()) {
                    Employee employee = new Employee();
                    employee.Id = Convert.ToInt32(dr[0]);
                    employee.Name = dr[1] as string;
                    employee.Designation = Convert.ToInt32(dr[2]);
                    employee.Department = Convert.ToInt32(dr[3]);
                    employees.Add(employee);
                }
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return employees;
        }

        public DataTable getDesigDAL()
        {
            DataTable desigList = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_GetDesignation]",con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                desigList = new DataTable();
                desigList.Load(dr);
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return desigList;
        }

        public DataTable getDeptDAL()
        {
            DataTable deptList = null;
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
                cmd = new SqlCommand("[At189753].[USP_GetDepartment]",con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                deptList = new DataTable();
                deptList.Load(dr);
            }
            catch (SqlException ex)
            {
                throw new HRDSExceptions(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return deptList;
        }
    }
}
