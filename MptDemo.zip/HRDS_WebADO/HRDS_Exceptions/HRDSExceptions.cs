﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRDS_Exceptions
{
    public class HRDSExceptions : ApplicationException
    {
        public HRDSExceptions() : base() { }
        public HRDSExceptions(string Message) : base(Message) { }
        public HRDSExceptions(string Message,Exception InnerException) : base(message : Message, innerException : InnerException) { }
    }
}
