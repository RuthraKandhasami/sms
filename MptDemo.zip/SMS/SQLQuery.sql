﻿select * from [190305].[Student] 


CREATE TABLE [190305].[Student] (
    [Rollno]               INT           IDENTITY (1, 1) NOT NULL,
    [FullName]             VARCHAR (30)  NULL,
    [Gender]               VARCHAR (6)   NULL,
    [DOB]                  DATETIME      NULL,
    [Contact]              VARCHAR (10)  NULL,
    [Emailid]              VARCHAR (20)  NULL,
    [ResedentialState]     VARCHAR (20)  NULL,
    [CommunicationAddress] VARCHAR (100) NULL,
	PRIMARY KEY CLUSTERED ([Rollno] ASC)
)
drop table [190305].Student