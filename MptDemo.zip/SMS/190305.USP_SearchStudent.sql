﻿CREATE PROCEDURE [190305].[USP_SearchStudent]
	@rollno int 	
AS
begin
	if(@rollno is null OR @rollno <0)
		Begin 
			Raiserror ('Student Id cannot be null or empty',1,1)
		end
		Else		
			Begin
			Select * from [190305].Student where Rollno = @rollno
			End
	End
RETURN 0