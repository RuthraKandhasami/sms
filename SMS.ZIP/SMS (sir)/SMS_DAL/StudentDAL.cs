﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

using SMS_Entities;

namespace SMS_DAL
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(@"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Amol_132419;Integrated Security=True");
        }
        public void Insert(Student student)
        {
            try
            {
                cmd = new SqlCommand("insert into Student values(@fullName,@gender,@dob,@mobNo,@email,@state,@add)", cn);
                cmd.Parameters.AddWithValue("@fullName", student.FullName);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@mobNo", student.MobileNo);
                cmd.Parameters.AddWithValue("@email", student.Email);
                cmd.Parameters.AddWithValue("@state", student.State);
                cmd.Parameters.AddWithValue("@add", student.Address);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
        public void Update(Student student)
        {
            try
            {
                cmd = new SqlCommand("update Student set FullName = @fullName, Gender = @gender, DOB = @dob, MobileNo = @mobNo, Email = @email, State = @state, Address = @add where RollNo = @rNo", cn);
                cmd.Parameters.AddWithValue("@rNo", student.RollNo);
                cmd.Parameters.AddWithValue("@fullName", student.FullName);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@mobNo", student.MobileNo);
                cmd.Parameters.AddWithValue("@email", student.Email);
                cmd.Parameters.AddWithValue("@state", student.State);
                cmd.Parameters.AddWithValue("@add", student.Address);
                cn.Open();
                cmd.ExecuteNonQuery();                
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
        }

        public Student SelectBy(int rollNo)
        {
            Student student = new Student();
            try
            {
                cmd = new SqlCommand("select * from Student where rollNo=@rNo", cn);
                cmd.Parameters.AddWithValue("@rNo", rollNo);
                cn.Open();                
                dr = cmd.ExecuteReader();
                if( dr.Read()) //
                {
                    student.RollNo = Convert.ToInt32(dr[0]);
                    student.FullName = dr[1].ToString();
                    student.Gender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.MobileNo = dr[4].ToString();
                    student.Email = dr[5].ToString();
                    student.State = dr[6].ToString();
                    student.Address = dr[7].ToString();
                }               
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return student;
        }

        public List<Student> SelectAll()
        {
            List<Student> students = new List<Student>();
            try
            {
                cmd = new SqlCommand("select * from Student", cn);              
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read()) //
                {
                    Student student = new Student();
                    student.RollNo = Convert.ToInt32(dr[0]);
                    student.FullName = dr[1].ToString();
                    student.Gender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.MobileNo = dr[4].ToString();
                    student.Email = dr[5].ToString();
                    student.State = dr[6].ToString();
                    student.Address = dr[7].ToString();
                    students.Add(student);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return students;
        }
    }
}
