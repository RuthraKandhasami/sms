﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Entities
{
    public class Student
    {
        public int StuID { get; set; }
        public string StuName { get; set; }
        public string StuGender { get; set; }
        public DateTime DOB { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string Comm_Address { get; set; }
        public string state { get; set; }
    }
}

