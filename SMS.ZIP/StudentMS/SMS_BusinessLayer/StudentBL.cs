﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_DataAccessLayer;
using SMS_Entities;
using SMS_Exceptions;

namespace SMS_BusinessLayer
{
    public class StudentBL
    {
        StudentDAL objDAL = new StudentDAL();

        public int InsertBL(Student student)
        {
            int stuid;
            try
            {
                 stuid = objDAL.insert(student);              
            }            
            catch (Exception e)
            {
                throw e;
            }
            return stuid;
        }
        public void UpdateBL(Student student)
        {

            try
            {
                objDAL.update(student);
            }            
            catch (Exception e)
            {
                throw e;
            }

        }
        public void DeleteBL(int studentid)
        {

            try
            {
                objDAL.delete(studentid);
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        public Student SearchBL(int stuid)
        {
            Student student = null;
            try
            {
                student = objDAL.search(stuid);
            }            
            catch (Exception e)
            {
                throw e;
            }
            return student;
        }
        public List<Student> SelectAllBL( )
        {
            List<Student> students = null;
            try
            {
                students = objDAL.SelectAll();
            }
            catch (Exception e)
            {
                throw e;
            }
            return students;
        }
    }
}
