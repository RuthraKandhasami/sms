﻿create table [190305].Departments
(
	Deptid int primary key,
	DeptName varchar(20)
)
insert into [190305].Departments values(100,'HR')
insert into [190305].Departments values(300,'ADMIN')
insert into [190305].Departments values(400,'OPERATION')
select * from [190305].Departments

create table [190305].Emp
(
	Empid int primary key,
	EmpName varchar(20),
	DeptId int,
	Salary money
)
insert into [190305].Emp values(1001,'Lalit',100,44200.00)
insert into [190305].Emp values(1002,'Kavita',100,44200.00)
insert into [190305].Emp values(1003,'Manoj',200,37000.00)
insert into [190305].Emp values(1004,'Jayeshri',200,24500.00)
insert into [190305].Emp values(1005,'Manish',300,44200.00)
insert into [190305].Emp(Empid,EmpName,Salary) values(1006,'Harshal',44200.00)
insert into [190305].Emp(Empid,EmpName,Salary) values(1007,'Kiran',44200.00)
select * from [190305].Emp

--inner join
select Empid,EmpName,DeptName from [190305].Emp 
inner join [190305].Departments on [190305].Emp.DeptId = [190305].Departments.Deptid

--without clustered index
create table [190305].temp
(
	id int ,
	description varchar(20)
)
insert into [190305].temp values(4,'i am 4')
insert into [190305].temp values(2,'i am 2')
insert into [190305].temp values(1,'i am 1')
insert into [190305].temp values(3,'i am 3')
select * from [190305].temp
drop table [190305].temp

--with clustered index  (creating indirectly)
create table [190305].temp
(
	id int primary key,
	description varchar(20)
)
insert into [190305].temp values(4,'i am 4')
insert into [190305].temp values(2,'i am 2')
insert into [190305].temp values(1,'i am 1')
insert into [190305].temp values(3,'i am 3')
select * from [190305].temp
drop table [190305].temp

--with non-clustered index  (creating indirectly)--
create table [190305].temp
(
	id int Unique,
	description varchar(20)
)
insert into [190305].temp values(4,'i am 4')
insert into [190305].temp values(2,'i am 2')
insert into [190305].temp values(1,'i am 1')
insert into [190305].temp values(3,'i am 3')
select * from [190305].temp
drop table [190305].temp

exec sp_helpindex temp
exec sp_helptext sp_help

--outer join
select EmpName,DeptName from [190305].Emp 
full outer join [190305].Departments on [190305].Emp.DeptId = [190305].Departments.Deptid

---view
create view [190305].EmpView(EmpName,DeptName)
as 
select EmpName,DeptName from [190305].Emp 
full outer join [190305].Departments on [190305].Emp.DeptId = [190305].Departments.Deptid

select * from [190305].EmpView
exec sp_helptext [190305.EmpView]

alter view [190305].EmpView(EmpName,DeptName) with encryption as 
select EmpName,DeptName from [190305].Emp 
full outer join [190305].Departments on [190305].Emp.DeptId = [190305].Departments.Deptid

--inserting in stored procedure
declare @emp int
exec @emp= [190305].[usp_insertEmp] 161,'Aishwarya',201,50000
print @emp

--updating in stored procedure
exec [190305].[usp_updateEmp] 101,'Abc',20,3000

--selecting in stored procedure
select * from  [190305].emp 

--deleting in stored procedure
exec [190305].[usp_DeleteEmp] 101

---stored procedure(function is mentioned in procedure usp_add) 
declare @result int 
exec @result = [190305].[usp_add] 20, 15
print @result --or select @result instead of print

--stored procedure using out parameter
declare @add int
declare @sub int
exec [190305].[usp_addsub] 10 , 5 , @add out , @sub out
select @add , @sub

