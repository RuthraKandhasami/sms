﻿create table [190305].Student
(
	Rollno int Identity(1,1),
	FullName varchar(30),
	Gender varchar(6),
	DOB datetime,
	Contact varchar(10),
	Emailid varchar(20),
	ResedentialState varchar(20),
	CommunicationAddress varchar(100)
)

drop table [190305].Student
select * from [190305].Student

