﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS_Entity;
using SMS_Exception;
using SMS_DAL;
using SMS_BL;

namespace SMS_Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBL bal = new StudentBL();

        public MainWindow()
        {
            InitializeComponent(); 
        }

        public void clear()
        {
            txt2.Text = txt.Text = txt1.Text = txt3.Text = txt4.Text = txt6.Selection.Text = string.Empty;
            Female.IsChecked = false;
            Male.IsChecked = false;
            txt5.SelectedIndex = 0;
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student();
            try
            {
                student.FullName = txt1.Text;
                if(Male.IsChecked == true)
                {
                    student.Gender = Male.Content.ToString();
                }
                else
                {
                    student.Gender = Female.Content.ToString();
                }
                student.DOB = (DateTime)txt2.SelectedDate;
                student.Contact = txt3.Text;
                student.Emailid = txt4.Text;
                student.ResedentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString();                
                txt6.SelectAll();
                student.CommunicationAddress = txt6.Selection.Text;
                bal.Add(student);

                int id;
                id = bal.Add(student);
                MessageBox.Show("Record Inserted for Rollno = " + id);
                clear();
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student();
            try
            {
                student.RollNo = Convert.ToInt32(txt.Text);
                student.FullName = txt1.Text;
                if (Male.IsChecked == true)
                {
                    student.Gender = Male.Content.ToString();
                }
                else
                {
                    student.Gender = Female.Content.ToString();
                }
                student.DOB = (DateTime)txt2.SelectedDate;
                student.Contact = txt3.Text;
                student.Emailid = txt4.Text;               
                txt6.SelectAll();
                student.CommunicationAddress = txt6.Selection.Text;
                student.ResedentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString();
                bal.Modify(student);
                MessageBox.Show("Record updated");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student();
            try
            {
                student.RollNo = Convert.ToInt32(txt.Text);
                bal.Remove(student.RollNo);
                MessageBox.Show("Record Deleted");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rollNo = int.Parse(txt.Text);
                Student student = bal.Search(rollNo);

                txt.Text = student.RollNo.ToString();
                txt1.Text = student.FullName.ToString();

                String gender = student.Gender;
                if (gender == "Male")
                {
                    Male.IsChecked = true;
                }
                else if (gender == "Female")
                {
                    Female.IsChecked = true;
                }
                txt2.Text = student.DOB.ToShortDateString().ToString();
                txt3.Text = student.Contact.ToString();
                txt4.Text = student.Emailid.ToString();
                txt6.Document.Blocks.Clear();
                txt6.Document.Blocks.Add(new Paragraph(new Run(student.CommunicationAddress)));

                foreach (ListBoxItem lbi in txt5.Items)
                {
                    if (lbi.Content.ToString() == student.ResedentialState.ToString())
                    {
                        lbi.IsSelected = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    
    }
}
