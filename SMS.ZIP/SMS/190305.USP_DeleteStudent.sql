﻿CREATE PROCEDURE [190305].[USP_DeleteStudent]
	@rollno int 	
AS
begin
	if(@rollno is null OR @rollno <0)
		Begin 
			Raiserror ('Student Id cannot be null or empty',1,1)
		end
		Else		
			Begin
			if exists (select Rollno from [190305].Student where Rollno = @rollno  ) 
			Begin
						delete from [190305].Student where Rollno = @rollno
			End		
			Else
			Begin
					RaisError('Student ID not Exists',1,1)
			end
		end
	end
RETURN 0
