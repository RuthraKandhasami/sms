﻿CREATE PROCEDURE [190305].[USP_UpdateStudent]
	@rollno int ,
	@FullName varchar(30),
	@gender varchar(6),
	@email varchar(20),
	@add varchar(100),
	@dob datetime,
	@mobNo varchar(10),
	@state varchar(20)
AS
BEGIN
		if (@rollno is null OR @rollno <0 ) 
		BEGIN
			RaisError('Student Id cannot be null or empty',1,1)
		END
	ELSE
		BEGIN
			if exists (select Rollno from [190305].Student where Rollno = @rollno ) 
			BEGIN
				update [190305].Student set
				 Rollno = @FullName ,
				 Gender = @gender,
				 DOB = @dob,
				 Contact =@mobNo,
				 Emailid = @email, 
				 CommunicationAddress = @add, 
				 ResedentialState = @state 
				 where 
				 Rollno = @rollno
			End
		Else
			Begin
					RaisError('Student ID not Exists',1,1)
			end
		end
	end
RETURN 0
