﻿CREATE PROCEDURE [190305].[USP_ViewStudent]
	@rollno int out,
	@FullName varchar(30),
	@gender varchar(6),
	@email varchar(20),
	@add varchar(100),
	@dob datetime,
	@mobNo varchar(10),
	@state varchar(20)
AS
	SELECT @rollno ,@FullName,@gender,@email,@add,@dob,@mobNo,@state
RETURN 0