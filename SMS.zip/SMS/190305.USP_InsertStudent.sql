﻿CREATE PROCEDURE [190305].[USP_InsertStudent]
	@rollno int out,
	@fullName varchar(30),
	@gender varchar(5),
	@dob date,
	@mobNo varchar(10),
	@email varchar(20),
	@state varchar(20),
	@add varchar(100)
AS
	insert into [190305].Student values (@fullName,@gender,@dob,@mobno,@email,@state,@add)
	set @rollNo=SCOPE_IDENTITY()
RETURN 0