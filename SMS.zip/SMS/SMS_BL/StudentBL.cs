﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entity;
using SMS_Exception;
using SMS_DAL;

namespace SMS_BL
{
    public class StudentBL
    {
        StudentDAL dal = new StudentDAL();

        public int Add(Student student)
        {
            int rollno;
            try
            {
                rollno = dal.Insert(student);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rollno;
        }

        public void Modify(Student student)
        {
            try
            {
                dal.Update(student);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Student Search(int rollNo)
        {
            Student student = null;
            try
            {
                student = dal.SelectBy(rollNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return student;
        }

        public void Remove(int rollNo)
        {
            try
            {
                dal.delete(rollNo);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public List<Student> view()
        {
            List<Student> student = null;
            try
            {
                student = dal.SelectAll();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return student;
        }
    }
}
